
import java.util.ArrayList;
import java.util.List;


public class Period {
    ArrayList<Exam> exams = new ArrayList<Exam>();
    int id;
    
    public void setId(int id)
    {
        this.id = id;
    }
    public int getId()
    {
        return this.id;
    }
    public boolean isInCoflict(Student s1 , Exam e2)
    {   
        for(int i = 0; i < e2.students.size(); i++)
        {
            if(e2.students.get(i).getId() == (s1.getId()));
            return true;
        }
       return false;
        
    }
}