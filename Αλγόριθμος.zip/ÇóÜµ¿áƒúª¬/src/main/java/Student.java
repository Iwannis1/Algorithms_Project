
import java.util.ArrayList;
import java.util.Arrays;


public class Student {
    
    int id;
    String[] courses;
    
  
    
    public void setId(int id)
    {
        this.id = id;
    }
    public int getId()
    {
        return id;
    }
    public void analyzeCourses()
    {
        for(int i = 0; i < courses.length; i++)
        {
            System.out.println(courses[i]);
        }
    }
    public boolean isInCourses(String course)
    {
        for(int i = 0; i < courses.length; i++)
        {
            if(courses[i].equals(course))
            {
                return true;
            }
        }
        return false;
    }
    public String [] getCourses()
    {
        return this.courses;
    }
}
