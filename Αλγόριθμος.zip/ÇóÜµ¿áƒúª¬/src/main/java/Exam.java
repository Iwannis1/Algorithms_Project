
import java.util.ArrayList;


public class Exam {
    ArrayList<Student> students = new ArrayList<Student>();
    String name;
    
    
    public void setName(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
   public void displayStudents()
   {
       for(int i = 0; i < students.size(); i++)
       {
           System.out.println(students.get(i).getId());
       }
   }
   public Student getStudent(int i)
   {
       return students.get(i);
   }
}
